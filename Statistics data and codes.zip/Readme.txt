This folder contains all the files needed for replicating the results included in the paper.

The csv and .zip files include data for simulations and empirical analyses, respecively. The important codes
are the following:

- covestim.R: this files includes the functions used to estimate covariance matrix estimators in the paper. These
functions are used in the simulation study;

- Simulations code.R: this files implements the simulation study;

- mvp.R: this code includes the function adopted for building portfolios with different estimators.
The results are equivalent of applying the estimators in covestim.R and then plug-in the estimates
in the MeanVariancePortfolio formula. In this codes we however use the results of Remark 1 in the paper;

- Applications code.R: this file implements the empirical anlysis, computes the Sharpe ration and the pvalues;

- Results evaluation code.R: this provides a faster way of proceeding the results obtained in the codes above.

Moreover, for the empirical analysis user can also load the results of the out-of-sample portfolios to access
the results faster. These are the files "results_m180.RDS", "results_m240.RDS" and "results_m360.RDS" for different
values of M.

The R version used is the 4.4.1. The used packages, with their version are the following.

attached base packages:
[1] compiler  parallel  stats     graphics  grDevices utils    
[7] datasets  methods   base     

other attached packages:
 [1] PeerPerformance_2.2.5 lmtest_0.9-40        
 [3] zoo_1.8-12            sandwich_3.1-0       
 [5] data.table_1.15.4     doParallel_1.0.17    
 [7] iterators_1.0.14      foreach_1.5.2        
 [9] MASS_7.3-60.2         nlshrink_1.0.1       
[11] RiskPortfolios_2.1.7  rio_1.1.1         