#------------- Performance evaluation (simulations)

rm(list=ls())
SRp10 <- rio::import("SRp10.RDS")
SRp30 <- rio::import("SRp30.RDS")
SRp48 <- rio::import("SRp48.RDS")

res <- matrix(NA, nrow=18, ncol=4)
for(i in 1:4){
  res[,i] <- SRp10[[i]]
}
rownames(res) <-  c("ML","SC","UP","c3","c*","I","Naive","EW","UP+EW",
                    "UP+I","UP+c3","c3+EW","c3+I","c*+EW","c*+I",
                    "LW1", "LW1", "NLS")
colnames(res) <- c("50","150","300","600")
res
apply((res),2,which.max)
xtable::xtable((res)*100, digits=4)

#------------- Performance evaluation (empirical)

rm(list=ls())
library(PeerPerformance)
results <- rio::import("results_m360.RDS") # Specify here results for what m

# Sharpe ratios 

res <- matrix(NA, nrow=15, ncol=12)
for(i in 1:12){
  res[,i] <- sharpe(results[[i]]) 
}
rownames(res) <-  c("EW","I","SC","PM","c3","c*","LW1",
                    "LW2","LW3","PM+I","PM+EW","c3+I","c3+EW",
                    "c*+I", "c*+EW")
xtable::xtable(round(res,6)*100)
apply(res, 2, which.max)

# p-values

respval <- matrix(NA, nrow=15, ncol=12)
for(i in 1:12){
  for (j in 1:14) {
    respval[j,i] <- sharpeTesting(results[[i]][,j], results[[i]][,15])$pval 
  }
}
rownames(respval) <-  c("EW","I","SC","PM","c3","c*","LW1",
                    "LW2","LW3","PM+I","PM+EW","c3+I","c3+EW",
                    "c*+I", "c*+EW")
xtable::xtable(respval)
